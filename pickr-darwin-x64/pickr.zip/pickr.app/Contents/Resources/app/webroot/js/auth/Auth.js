(function() {
	'use strict';

	angular.module('Auth', ['ngMaterial', 'Config']);
})();

