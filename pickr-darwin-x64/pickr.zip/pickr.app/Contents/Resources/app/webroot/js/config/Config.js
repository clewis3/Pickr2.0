(function() {
	'use strict';

	angular.module('Config', ['ngMaterial']);
})();

