(function() {
	'use strict';

	angular.module('Student', ['ngMaterial']);
})();

